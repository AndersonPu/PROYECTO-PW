export interface User{
    "id" :number;
    "name" :string;
    "lastname": string;
    "username" :string;
    "email": string;
}