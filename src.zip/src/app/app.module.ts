import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Route } from '@angular/router';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { FormularioComponent } from './formulario/formulario.component';
import { GaleriaComponent } from './galeria/galeria.component';
import { GastosComponent } from './gastos/gastos.component';
import { HttpClientModule } from '@angular/common/http';
import { DataService } from './data.service';
import { ReporteComponent } from './reporte/reporte.component';
import { FormsModule } from '@angular/forms';

const rutas: RouterModule[]=[
  {path:'informacion', component:GastosComponent},
  {path:'formulario', component:FormularioComponent},
  {path:'reporte', component:ReporteComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    FormularioComponent,
    GaleriaComponent,
    GastosComponent,
    ReporteComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(rutas),
    HttpClientModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
