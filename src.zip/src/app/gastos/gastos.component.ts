import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gastos',
  templateUrl: './gastos.component.html',
  styleUrls: ['./gastos.component.css']
})
export class GastosComponent implements OnInit {
  
  

  ngOnInit(): void {
  }
  gasto =[
    {
        "titulo": "Vivienda",
        "descripcion": "Vivienda de la region Sierra.",
        "info":"El Ministerio de Desarrollo Urbano y Vivienda de Ecuador es la cartera de Estado encargada de ejercer la rectoría e implementar la política pública de las ciudades, garantizando a la ciudadanía el acceso al hábitat seguro y saludable, a la vivienda digna y al espacio público integrador."
    },
    {
      "titulo": "Educacion",
        "descripcion": "La Educacion de la region Sierra.",
        "info":"La educación es el proceso de facilitar el aprendizaje o la adquisición de conocimientos, habilidades"
    },
    {
      "titulo": "Alimentacion",
        "descripcion": "La alimentacion ",
        "info":"La alimentación es la actividad mediante la que tomamos del mundo exterior una serie de sustancias necesarias para poder nutrirnos. "
    },
      {
        "titulo": "Salud",
        "descripcion": "Salud para Todos",
        "info":"El Ministerio de Salud Pública de Ecuador es la cartera del Estado encargada de ejercer la rectoría, regulación, planificación, coordinación, control y gestión de la salud pública ecuatoriana"
      }
    ];

  
  

  informacion(gasto : string){
    alert(gasto);
  }

 

 borrarGasto (gasto:string){
    for (let i=0; i<this.gasto.length;i++)
    {
      if( gasto == this.gasto[i].titulo){
        this.gasto.splice(i,1);
      }
    }
  }
}


