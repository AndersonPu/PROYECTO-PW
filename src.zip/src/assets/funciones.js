document.getElementById("titulo").innerHTML="Calculadora de Impuesto a la Renta SRI";
document.getElementById("dato1").innerHTML="Ingresos";
document.getElementById("dato2").innerHTML="Gastos";
document.getElementById("dato3").innerHTML="Base imponible";

let boton = document.getElementById("dato3");
let boton2 = document.getElementById("dato4");
let respuesta = document.getElementById("resp");
let r1 = document.getElementById("r1");
let r2 = document.getElementById("r2");
let r3 = document.getElementById("r3");

let FraccionBasica=[0,11.212,14.285,17.854,21.442,42.874,64.297,85.729];
let ExcesoHasta=[11.212,14.285,17.854,21.442,42.874,64.297,85.729,114.288];
let impuestoFraccionBasica=[0,0,154,511,941,4.156,8.440,13.798];
let FraccionExcedente=[0,5,10,12,15,20,25,30];
boton.addEventListener('click',impuesto);

function impuesto(){
    
    let d1=parseFloat(document.getElementById('d1').value);
    let d2=parseFloat(document.getElementById('d2').value);
    /*respuesta.innerHTML= `Base imponible: ${s}`;*/
    let base_imponible=d1-d2;
    if (base_imponible>0 && base_imponible<=11212){
          let exedente=base_imponible-0;
          let por_exedente=exedente*0;
          let impuestos=0+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>11212 && base_imponible<=14285){
        let exedente=base_imponible-11212;
        let por_exedente=exedente*0.05;
        let impuestos=0+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>14285 && base_imponible<=17854){
          let exedente=base_imponible-14280;
          let por_exedente=exedente*0.10;
          let impuestos=154+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>17854 && base_imponible<=21442){
         let exedente=base_imponible-17854;
         let por_exedente=exedente*0.12;
         let impuestos=511+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>21442 && base_imponible<=42874){
         let exedente=base_imponible-21442;
         let por_exedente=exedente*0.15;
         let impuestos=941+por_exedente;
         r1.innerHTML= `${base_imponible}`;
         r2.innerHTML= `${por_exedente.toFixed(2)}`;
         r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>42874 && base_imponible<=64297){
         let exedente=base_imponible-42874;
         let por_exedente=exedente*0.20;
         let impuestos=4156+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
    }
    if (base_imponible>64297 && base_imponible<=85729){
        let exedente=base_imponible-64297;
        let por_exedente=exedente*0.25;
        let impuestos=8440+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;
   }
    if (base_imponible>85729 && base_imponible<=114288){
         let exedente=base_imponible-85729;
         let por_exedente=exedente*0.30;
         let impuestos=13798+por_exedente;
          r1.innerHTML= `${base_imponible}`;
          r2.innerHTML= `${por_exedente.toFixed(2)}`;
          r3.innerHTML= `${impuestos}`;;
    }

}
document.getElementById("c1").innerHTML="Datos";
document.getElementById("c2").innerHTML="Resultados";
document.getElementById("t1").innerHTML="Base Imponible";
document.getElementById("t2").innerHTML="Porcentaje Excedente";
document.getElementById("t3").innerHTML="Impuesto";

function limpiar(){
    document.getElementById('Formulario').reset();
}

